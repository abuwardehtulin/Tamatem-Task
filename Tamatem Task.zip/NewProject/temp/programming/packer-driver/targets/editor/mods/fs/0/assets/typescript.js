System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, Sprite, Button, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _temp, _crd, ccclass, property, Typescript;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Sprite = _cc.Sprite;
      Button = _cc.Button;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f5387YSq/hE1qDJf1hJWBC+", "typescript", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Typescript", Typescript = (_dec = ccclass('Typescript'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(Node), _dec6 = property(Node), _dec7 = property(Node), _dec8 = property(Button), _dec9 = property(Button), _dec(_class = (_class2 = (_temp = class Typescript extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "backgroundSky", _descriptor, this);

          _initializerDefineProperty(this, "backgroundFarMountain", _descriptor2, this);

          _initializerDefineProperty(this, "backgroundCloseMountain", _descriptor3, this);

          _initializerDefineProperty(this, "backgroundGround", _descriptor4, this);

          _initializerDefineProperty(this, "backgroundMain", _descriptor5, this);

          _initializerDefineProperty(this, "character", _descriptor6, this);

          _initializerDefineProperty(this, "skySpeed", _descriptor7, this);

          _initializerDefineProperty(this, "farMountainSpeed", _descriptor8, this);

          _initializerDefineProperty(this, "closeMountainSpeed", _descriptor9, this);

          _initializerDefineProperty(this, "groundSpeed", _descriptor10, this);

          _initializerDefineProperty(this, "mainBackgroundSpeed", _descriptor11, this);

          _defineProperty(this, "dragDistance", 0);

          _initializerDefineProperty(this, "moveLeftButton", _descriptor12, this);

          _initializerDefineProperty(this, "moveRightButton", _descriptor13, this);
        }

        // Button to move right
        start() {
          console.log('Parallax Effect Started!'); // Add event listeners to buttons

          this.moveLeftButton.node.on('click', this.moveLeft, this);
          this.moveRightButton.node.on('click', this.moveRight, this);
        }

        moveLeft() {
          this.dragDistance -= 10; // Move left by 10 units

          this.updateBackgroundPosition(this.dragDistance);
          this.updateCharacterPosition(this.dragDistance); // Move character
        }

        moveRight() {
          this.dragDistance += 10; // Move right by 10 units

          this.updateBackgroundPosition(this.dragDistance);
          this.updateCharacterPosition(this.dragDistance); // Move character
        }

        update(deltaTime) {
          // Automatically move the backgrounds to the right with different speeds (without drag)
          if (this.dragDistance === 0) {
            this.backgroundSky.setPosition(this.backgroundSky.position.x + this.skySpeed * deltaTime, this.backgroundSky.position.y, 0);
            this.backgroundFarMountain.setPosition(this.backgroundFarMountain.position.x + this.farMountainSpeed * deltaTime, this.backgroundFarMountain.position.y, 0);
            this.backgroundCloseMountain.setPosition(this.backgroundCloseMountain.position.x + this.closeMountainSpeed * deltaTime, this.backgroundCloseMountain.position.y, 0);
            this.backgroundGround.setPosition(this.backgroundGround.position.x + this.groundSpeed * deltaTime, this.backgroundGround.position.y, 0);
            this.backgroundMain.setPosition(this.backgroundMain.position.x + this.mainBackgroundSpeed * deltaTime, this.backgroundMain.position.y, 0);
          } // Reset positions if they move off screen (right side)


          this.checkAndResetPosition(this.backgroundSky);
          this.checkAndResetPosition(this.backgroundFarMountain);
          this.checkAndResetPosition(this.backgroundCloseMountain);
          this.checkAndResetPosition(this.backgroundGround);
          this.checkAndResetPosition(this.backgroundMain);
        }

        checkAndResetPosition(background) {
          if (background.position.x >= background.getComponent(Sprite).size.width) {
            background.setPosition(-background.getComponent(Sprite).size.width, background.position.y, 0);
          } else if (background.position.x <= -background.getComponent(Sprite).size.width) {
            background.setPosition(background.getComponent(Sprite).size.width, background.position.y, 0);
          }
        }

        updateBackgroundPosition(dragDistance) {
          // Move all backgrounds according to the drag distance
          this.backgroundSky.setPosition(this.backgroundSky.position.x + dragDistance, this.backgroundSky.position.y, 0);
          this.backgroundFarMountain.setPosition(this.backgroundFarMountain.position.x + dragDistance, this.backgroundFarMountain.position.y, 0);
          this.backgroundCloseMountain.setPosition(this.backgroundCloseMountain.position.x + dragDistance, this.backgroundCloseMountain.position.y, 0);
          this.backgroundGround.setPosition(this.backgroundGround.position.x + dragDistance, this.backgroundGround.position.y, 0);
          this.backgroundMain.setPosition(this.backgroundMain.position.x + dragDistance, this.backgroundMain.position.y, 0);
        }

        updateCharacterPosition(dragDistance) {
          // Move the character the same way as the background (sync movement)
          this.character.setPosition(this.character.position.x + dragDistance, this.character.position.y, this.character.position.z);
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "backgroundSky", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "backgroundFarMountain", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "backgroundCloseMountain", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "backgroundGround", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "backgroundMain", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "character", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "skySpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 20;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "farMountainSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 40;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "closeMountainSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 60;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "groundSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 80;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "mainBackgroundSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "moveLeftButton", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "moveRightButton", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=typescript.js.map