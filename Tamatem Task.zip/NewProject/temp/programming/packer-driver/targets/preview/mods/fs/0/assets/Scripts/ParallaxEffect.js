System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, Vec3, UITransform, director, Canvas, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp, _crd, ccclass, property, ParallaxEffect;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      UITransform = _cc.UITransform;
      director = _cc.director;
      Canvas = _cc.Canvas;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "3c439QCRBBJ36jzJVqB0bXP", "ParallaxEffect", undefined);

      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("ParallaxEffect", ParallaxEffect = (_dec = ccclass('ParallaxEffect'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inheritsLoose(ParallaxEffect, _Component);

        function ParallaxEffect() {
          var _this;

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _Component.call.apply(_Component, [this].concat(args)) || this;

          _initializerDefineProperty(_assertThisInitialized(_this), "image1", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_assertThisInitialized(_this), "image2", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_assertThisInitialized(_this), "image3", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_assertThisInitialized(_this), "gameSpeed", _descriptor4, _assertThisInitialized(_this));

          _initializerDefineProperty(_assertThisInitialized(_this), "Y", _descriptor5, _assertThisInitialized(_this));

          _defineProperty(_assertThisInitialized(_this), "imageWidth1", void 0);

          _defineProperty(_assertThisInitialized(_this), "imageWidth2", void 0);

          _defineProperty(_assertThisInitialized(_this), "imageWidth3", void 0);

          _defineProperty(_assertThisInitialized(_this), "canvasWidth", void 0);

          return _this;
        }

        var _proto = ParallaxEffect.prototype;

        _proto.onLoad = function onLoad() {
          this.startUp();
        };

        _proto.startUp = function startUp() {
          this.imageWidth1 = this.image1.getComponent(UITransform).width;
          this.imageWidth2 = this.image2.getComponent(UITransform).width;
          this.imageWidth3 = this.image3.getComponent(UITransform).width;
          this.canvasWidth = director.getScene().getComponentInChildren(Canvas).getComponent(UITransform).width;
          this.setImageStartingPositions();
        };

        _proto.setImageStartingPositions = function setImageStartingPositions() {
          this.image1.setPosition(new Vec3(0, this.Y, 0));
          this.image2.setPosition(new Vec3(this.imageWidth1, this.Y, 0));
          this.image3.setPosition(new Vec3(this.imageWidth1 * 2, this.Y, 0));
        };

        _proto.update = function update(deltaTime) {
          this.moveImages(deltaTime);
          this.checkAndWrapImages();
        };

        _proto.moveImages = function moveImages(deltaTime) {
          this.image1.setPosition(this.image1.position.x - this.gameSpeed * deltaTime, this.Y, this.image1.position.z);
          this.image2.setPosition(this.image2.position.x - this.gameSpeed * deltaTime, this.Y, this.image2.position.z);
          this.image3.setPosition(this.image3.position.x - this.gameSpeed * deltaTime, this.Y, this.image3.position.z);
        };

        _proto.checkAndWrapImages = function checkAndWrapImages() {
          if (this.image1.position.x <= 0 - this.imageWidth1) {
            this.image1.setPosition(this.canvasWidth, this.Y, this.image1.position.z);
          }

          if (this.image2.position.x <= 0 - this.imageWidth2) {
            this.image2.setPosition(this.canvasWidth, this.Y, this.image2.position.z);
          }

          if (this.image3.position.x <= 0 - this.imageWidth3) {
            this.image3.setPosition(this.canvasWidth, this.Y, this.image3.position.z);
          }
        };

        return ParallaxEffect;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "image1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "image2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "image3", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gameSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 50;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "Y", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 50;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ParallaxEffect.js.map