import { _decorator, Component, Node, Animation } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Jump')
export class Jump extends Component {
    @property(Node)
    jumpButton: Node = null!; 

    @property(Animation)
    dinosaurAnim: Animation = null!;  

    start () {
       
        this.jumpButton.on('click', this.jump, this);
    }

    jump() {
        
        this.dinosaurAnim.play('Jump');
    }
}
