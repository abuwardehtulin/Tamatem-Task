import { _decorator, Component, Node, Vec3, UITransform, director, Canvas } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ParallaxEffect')
export class ParallaxEffect extends Component {
    @property(Node)
    public image1: Node;

    @property(Node)
    public image2: Node;

    @property(Node)
    public image3: Node;
    
    @property
    gameSpeed: number = 50;

    @property
    Y: number = 50;
    
    private imageWidth1: number;
    private imageWidth2: number;
    private imageWidth3: number;

    private canvasWidth: number; 
   

    onLoad() {
        this.startUp();
    }

    startUp() {
        this.imageWidth1 = this.image1.getComponent(UITransform).width;
        this.imageWidth2 = this.image2.getComponent(UITransform).width;
        this.imageWidth3 = this.image3.getComponent(UITransform).width;

        this.canvasWidth = director.getScene().getComponentInChildren(Canvas).getComponent(UITransform).width;

        this.setImageStartingPositions();
    }

    setImageStartingPositions() {
        this.image1.setPosition(new Vec3(0, this.Y, 0));
        this.image2.setPosition(new Vec3(this.imageWidth1, this.Y, 0));
        this.image3.setPosition(new Vec3(this.imageWidth1 * 2, this.Y, 0));
    }

    update(deltaTime: number) {
        this.moveImages(deltaTime);
        this.checkAndWrapImages();
    }

    moveImages(deltaTime: number) {
        this.image1.setPosition(this.image1.position.x - this.gameSpeed * deltaTime, this.Y, this.image1.position.z);
        this.image2.setPosition(this.image2.position.x - this.gameSpeed * deltaTime, this.Y, this.image2.position.z);
        this.image3.setPosition(this.image3.position.x - this.gameSpeed * deltaTime, this.Y, this.image3.position.z);
    }

    checkAndWrapImages() {
        if (this.image1.position.x <= (0 - this.imageWidth1)) {
            this.image1.setPosition(this.canvasWidth, this.Y, this.image1.position.z);
        }
        if (this.image2.position.x <= (0 - this.imageWidth2)) {
            this.image2.setPosition(this.canvasWidth, this.Y, this.image2.position.z);
        }
        if (this.image3.position.x <= (0 - this.imageWidth3)) {
            this.image3.setPosition(this.canvasWidth, this.Y, this.image3.position.z);
        }
    }
}
