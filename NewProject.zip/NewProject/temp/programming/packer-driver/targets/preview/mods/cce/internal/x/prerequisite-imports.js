System.register(["file:///C:/Users/User/NewProject/assets/Scripts/Jump.ts", "file:///C:/Users/User/NewProject/assets/Scripts/ParallaxEffect.ts"], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_fileCUsersUserNewProjectAssetsScriptsJumpTs) {}, function (_fileCUsersUserNewProjectAssetsScriptsParallaxEffectTs) {}],
    execute: function () {}
  };
});
//# sourceMappingURL=prerequisite-imports.js.map