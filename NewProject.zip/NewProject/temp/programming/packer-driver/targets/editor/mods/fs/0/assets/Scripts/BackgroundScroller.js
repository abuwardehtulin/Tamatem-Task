System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, Vec3, UITransform, director, Canvas, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp, _crd, ccclass, property, BackgroundScroller;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      UITransform = _cc.UITransform;
      director = _cc.director;
      Canvas = _cc.Canvas;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1864fwnVR1BFbhXObDEGjFT", "BackgroundScroller", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BackgroundScroller", BackgroundScroller = (_dec = ccclass('BackgroundScroller'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Node), _dec(_class = (_class2 = (_temp = class BackgroundScroller extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "ground1", _descriptor, this);

          _initializerDefineProperty(this, "ground2", _descriptor2, this);

          _initializerDefineProperty(this, "ground3", _descriptor3, this);

          _initializerDefineProperty(this, "gameSpeed", _descriptor4, this);

          _initializerDefineProperty(this, "Y", _descriptor5, this);

          _defineProperty(this, "groundWidth1", void 0);

          _defineProperty(this, "groundWidth2", void 0);

          _defineProperty(this, "groundWidth3", void 0);

          _defineProperty(this, "canvasWidth", void 0);
        }

        // Cache the canvas width for performance
        onLoad() {
          this.startUp();
        }

        startUp() {
          // Get ground width
          this.groundWidth1 = this.ground1.getComponent(UITransform).width;
          this.groundWidth2 = this.ground2.getComponent(UITransform).width;
          this.groundWidth3 = this.ground3.getComponent(UITransform).width; // Cache the canvas width

          this.canvasWidth = director.getScene().getComponentInChildren(Canvas).getComponent(UITransform).width; // Set temporary starting locations of ground

          this.setGroundStartingPositions();
        }

        setGroundStartingPositions() {
          // Set starting positions
          this.ground1.setPosition(new Vec3(0, this.Y, 0));
          this.ground2.setPosition(new Vec3(this.groundWidth1, this.Y, 0));
          this.ground3.setPosition(new Vec3(this.groundWidth1 * 2, this.Y, 0));
        }

        update(deltaTime) {
          // Move the ground positions based on game speed and deltaTime
          this.moveGrounds(deltaTime); // Check and wrap ground elements if they go out of bounds

          this.checkAndWrapGrounds();
        }

        moveGrounds(deltaTime) {
          // Move the ground nodes on the X-axis
          this.ground1.setPosition(this.ground1.position.x - this.gameSpeed * deltaTime, this.Y, this.ground1.position.z);
          this.ground2.setPosition(this.ground2.position.x - this.gameSpeed * deltaTime, this.Y, this.ground2.position.z);
          this.ground3.setPosition(this.ground3.position.x - this.gameSpeed * deltaTime, this.this.Y, this.ground3.position.z);
        }

        checkAndWrapGrounds() {
          // Check and wrap ground elements if they go out of bounds
          if (this.ground1.position.x <= 0 - this.groundWidth1) {
            this.ground1.setPosition(this.canvasWidth, this.Y, this.ground1.position.z);
          }

          if (this.ground2.position.x <= 0 - this.groundWidth2) {
            this.ground2.setPosition(this.canvasWidth, this.Y, this.ground2.position.z);
          }

          if (this.ground3.position.x <= 0 - this.groundWidth3) {
            this.ground3.setPosition(this.canvasWidth, this.Y, this.ground3.position.z);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "ground1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "ground2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "ground3", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "gameSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 50;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "Y", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 50;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=BackgroundScroller.js.map