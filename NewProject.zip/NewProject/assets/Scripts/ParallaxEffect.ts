import { _decorator, Component, Node, Vec3, UITransform, director, Canvas } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ParallaxEffect')
export class ParallaxEffect extends Component {
    // Properties to hold the background image nodes
    @property(Node)
    public image1: Node;

    @property(Node)
    public image2: Node;

    @property(Node)
    public image3: Node;
    
    // Game speed, controls the movement speed of the images
    @property
    gameSpeed: number = 50;

    // Y position of the images
    @property
    Y: number = 50;
    
    // Width variables for each image to track their individual widths
    private imageWidth1: number;
    private imageWidth2: number;
    private imageWidth3: number;

    // Width of the canvas to wrap images when they move off-screen
    private canvasWidth: number; 

    // This method is called when the component is loaded
    onLoad() {
        this.startUp(); // Initialize image positions
    }

    // Initialize positions and widths of the images
    startUp() {
        this.imageWidth1 = this.image1.getComponent(UITransform).width;
        this.imageWidth2 = this.image2.getComponent(UITransform).width;
        this.imageWidth3 = this.image3.getComponent(UITransform).width;

        // Get the width of the canvas to handle image wrapping
        this.canvasWidth = director.getScene().getComponentInChildren(Canvas).getComponent(UITransform).width;

        // Set the starting positions of the images
        this.setImageStartingPositions();
    }

    // Set the starting positions of the images
    setImageStartingPositions() {
        this.image1.setPosition(new Vec3(0, this.Y, 0)); // Position the first image
        this.image2.setPosition(new Vec3(this.imageWidth1, this.Y, 0)); // Position the second image
        this.image3.setPosition(new Vec3(this.imageWidth1 * 2, this.Y, 0)); // Position the third image
    }

    // This method is called every frame to update the image positions
    update(deltaTime: number) {
        this.moveImages(deltaTime); // Move images based on game speed
        this.checkAndWrapImages(); // Check if images need to be wrapped around
    }

    // Move images based on the game speed
    moveImages(deltaTime: number) {
        this.image1.setPosition(this.image1.position.x - this.gameSpeed * deltaTime, this.Y, this.image1.position.z);
        this.image2.setPosition(this.image2.position.x - this.gameSpeed * deltaTime, this.Y, this.image2.position.z);
        this.image3.setPosition(this.image3.position.x - this.gameSpeed * deltaTime, this.Y, this.image3.position.z);
    }

    // Wrap the images around when they move off-screen
    checkAndWrapImages() {
        // If image1 moves off-screen, move it to the right side
        if (this.image1.position.x <= (0 - this.imageWidth1)) {
            this.image1.setPosition(this.canvasWidth, this.Y, this.image1.position.z);
        }
        // If image2 moves off-screen, move it to the right side
        if (this.image2.position.x <= (0 - this.imageWidth2)) {
            this.image2.setPosition(this.canvasWidth, this.Y, this.image2.position.z);
        }
        // If image3 moves off-screen, move it to the right side
        if (this.image3.position.x <= (0 - this.imageWidth3)) {
            this.image3.setPosition(this.canvasWidth, this.Y, this.image3.position.z);
        }
    }
}
