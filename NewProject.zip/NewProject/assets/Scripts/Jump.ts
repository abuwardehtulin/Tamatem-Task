import { _decorator, Component, Node, Animation } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Jump')
export class Jump extends Component {
     // Property to hold the reference to the jump button node
    @property(Node)
    jumpButton: Node = null!; 

    // Property to hold the reference to the character's animation
    @property(Animation)
    CharacterAnim: Animation = null!;  

     // Called when the component is initialized
    start () {
        // Set up a click event listener on the jump button
        this.jumpButton.on('click', this.jump, this);
    }

     // Trigger the jump animation when the button is clicked
    jump() {
        // Play the jump animation on the character
        this.CharacterAnim.play('Jump');
    }
}
